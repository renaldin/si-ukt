

<?php $__env->startSection('content'); ?>
<section>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-box">
                <div class="form-title-wrap">
                    <div>
                        <h3 class="title"><?php echo e($subTitle); ?></h3>
                        <p class="font-size-14">Form <?php echo e($subTitle); ?></p>
                    </div>
                </div>
                <div class="form-content">
                    <div class="contact-form-action">
                        <form <?php if($form === 'Tambah'): ?> action="/tambah-reklame"  <?php else: ?> action="/edit-reklame/<?php echo e($reklame->id_reklame); ?>" <?php endif; ?> method="Post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Lokasi</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="lokasi" placeholder="Masukkan Lokasi" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->lokasi); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->lokasi); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('lokasi')); ?>" <?php endif; ?> autofocus>
                                        </div>
                                        <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Ukuran</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="ukuran" placeholder="Masukkan Ukuran" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->ukuran); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->ukuran); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('ukuran')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['ukuran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Alamat Lengkap</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="alamat" placeholder="Masukkan Alamat Lengkap" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->alamat); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->alamat); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('alamat')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Orientation Page</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="orientation_page" placeholder="Masukkan Orientation Page" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->orientation_page); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->orientation_page); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('orientation_page')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['orientation_page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Penerangan</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="penerangan" placeholder="Masukkan Penerangan" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->penerangan); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->penerangan); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('penerangan')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['penerangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Jarak Pandang</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="jarak_pandang" placeholder="Masukkan Jarak Pandang" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->jarak_pandang); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->jarak_pandang); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('jarak_pandang')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['jarak_pandang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Jumlah Sisi</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="jumlah_sisi" placeholder="Masukkan Jumlah Sisi" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->jumlah_sisi); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->jumlah_sisi); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('jumlah_sisi')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['jumlah_sisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>          
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Situasi Lalu Lintas</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="situasi_lalulintas" placeholder="Masukkan Situasi Lalu Lintas" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->situasi_lalulintas); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->situasi_lalulintas); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('situasi_lalulintas')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['situasi_lalulintas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Situasi Sekitar</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="situasi_sekitar" placeholder="Masukkan Situasi Sekitar" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->situasi_sekitar); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->situasi_sekitar); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('situasi_sekitar')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['situasi_sekitar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Target Audiens</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="target_audiens" placeholder="Masukkan Target Audiens" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->target_audiens); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->target_audiens); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('target_audiens')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['target_audiens'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Google Maps <?php if($form !== 'Detail'): ?> <small class="text-danger">Isi dengan iframe yang ada di Google Maps</small> <?php endif; ?></label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="google_maps" placeholder="Masukkan Google Maps" <?php if($form === 'Edit'): ?> value="<?php echo e($reklame->google_maps); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($reklame->google_maps); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('google_maps')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['google_maps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Gambar</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="file" name="gambar" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($form === 'Detail'): ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Gambar</label>
                                        <div class="form-group">
                                            <img src="<?php echo e(asset('foto_reklame/'.$reklame->gambar)); ?>" width="100%" alt="<?php echo e($reklame->gambar); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Google Maps</label>
                                        <div class="table-responsive">
                                            <?= $reklame->google_maps ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="btn-box pt-3 pb-4">
                                <center>
                                    <button type="submit" class="theme-btn w-50">Simpan</button>
                                </center>
                            </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div><!-- end form-box -->
        </div><!-- end col-lg-12 -->
    </div><!-- end row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/reklame/form.blade.php ENDPATH**/ ?>