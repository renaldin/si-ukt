

<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>SI UKT | <?php echo e($subTitle); ?></title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?php echo e(asset('template/html/assets/images/favicon.ico')); ?>" />
      
      <!-- Library / Plugin Css Build -->
      <link rel="stylesheet" href="<?php echo e(asset('template/html/assets/css/core/libs.min.css')); ?>" />
      
      <!-- Aos Animation Css -->
      <link rel="stylesheet" href="<?php echo e(asset('template/html/assets/vendor/aos/dist/aos.css')); ?>" />
      
      <!-- Hope Ui Design System Css -->
      <link rel="stylesheet" href="<?php echo e(asset('template/html/assets/css/hope-ui.min.css?v=1.2.0')); ?>" />
      
      <!-- Custom Css -->
      <link rel="stylesheet" href="<?php echo e(asset('template/html/assets/css/custom.min.css?v=1.2.0')); ?>" />
      
      <!-- Dark Css -->
      <link rel="stylesheet" href="<?php echo e(asset('template/html/assets/css/dark.min.css')); ?>"/>
      
      <!-- Customizer Css -->
      <link rel="stylesheet" href="<?php echo e(asset('template/html/assets/css/customizer.min.css')); ?>" />
      
      <!-- RTL Css -->
      <link rel="stylesheet" href="<?php echo e(asset('template/html/assets/css/rtl.min.css')); ?>"/>
      
  </head>
  <body class="  ">
    <!-- loader Start -->
    <div id="loading">
      <div class="loader simple-loader">
          <div class="loader-body"></div>
      </div>    
    </div>
    <!-- loader END -->
    
    
    <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

    <main class="main-content">
      <div class="position-relative iq-banner">
        <!--Nav Start-->
        <nav class="nav navbar navbar-expand-lg navbar-light iq-navbar">
          <div class="container-fluid navbar-inner">
            <a href="#" class="navbar-brand">
                <!--Logo start-->
                <svg width="30" class="text-primary" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="-0.757324" y="19.2427" width="28" height="4" rx="2" transform="rotate(-45 -0.757324 19.2427)" fill="currentColor"/>
                    <rect x="7.72803" y="27.728" width="28" height="4" rx="2" transform="rotate(-45 7.72803 27.728)" fill="currentColor"/>
                    <rect x="10.5366" y="16.3945" width="16" height="4" rx="2" transform="rotate(45 10.5366 16.3945)" fill="currentColor"/>
                    <rect x="10.5562" y="-0.556152" width="28" height="4" rx="2" transform="rotate(45 10.5562 -0.556152)" fill="currentColor"/>
                </svg>
                <!--logo End-->        <h4 class="logo-title">Hope UI</h4>
            </a>
            <div class="sidebar-toggle" data-toggle="sidebar" data-active="true">
                <i class="icon">
                 <svg width="20px" height="20px" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" />
                </svg>
                </i>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon">
                  <span class="mt-2 navbar-toggler-bar bar1"></span>
                  <span class="navbar-toggler-bar bar2"></span>
                  <span class="navbar-toggler-bar bar3"></span>
                </span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="mb-2 navbar-nav ms-auto align-items-center navbar-list mb-lg-0">
                <li class="nav-item dropdown">
                  <a class="py-0 nav-link d-flex align-items-center" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="<?php if($user->foto_user === null): ?> <?php echo e(asset('foto_user/default1.jpg')); ?> <?php else: ?> <?php echo e(asset('foto_user/'.$user->foto_user)); ?> <?php endif; ?>" alt="User-Profile" class="theme-color-default-img img-fluid avatar avatar-50 avatar-rounded">
                    <div class="caption ms-3 d-none d-md-block ">
                        <h6 class="mb-0 caption-title"><?php if($user->status === 'Bagian Keuangan' || $user->status === 'Kabag Umum & Akademik' || $user->status === 'Akademik'): ?><?php echo e($user->nama_user); ?><?php elseif($user->status === 'Mahasiswa'): ?><?php echo e($user->nama_mahasiswa); ?><?php endif; ?></h6>
                        <p class="mb-0 caption-sub-title"><?php echo e($user->status); ?></p>
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="<?php if($user->status === 'Bagian Keuangan'||$user->status === 'Kabag Umum & Akademik'||$user->status === 'Akademik'): ?> /profil <?php elseif($user->status === 'Mahasiswa'): ?> /profil-mahasiswa <?php endif; ?>">Profil</a></li>
                    <li><a class="dropdown-item" href="<?php if($user->status === 'Bagian Keuangan'||$user->status === 'Kabag Umum & Akademik'||$user->status === 'Akademik'): ?> /ubah-password <?php elseif($user->status === 'Mahasiswa'): ?> /ubah-password-mahasiswa <?php endif; ?>">Ubah Password</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#logout">Logout</button></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>          <!-- Nav Header Component Start -->
          <div class="iq-navbar-header" style="height: 215px;">
              <div class="container-fluid iq-container">
                  <div class="row">
                      <div class="col-md-12">
                          <div class="flex-wrap d-flex justify-content-between align-items-center">
                              <div>
                                <?php if($subTitle === 'Dashboard'): ?>
                                  <h1>Hello, <?php if($user->status === 'Bagian Keuangan' || $user->status === 'Kabag Umum & Akademik' || $user->status === 'Akademik'): ?><?php echo e($user->nama_user); ?><?php elseif($user->status === 'Mahasiswa'): ?><?php echo e($user->nama_mahasiswa); ?><?php endif; ?></h1>
                                  <p>Selamat Datang Di Website Sistem Informasi Uang Kuliah Tunggal (UKT).</p>
                                <?php else: ?>
                                  <h1><?php echo e($subTitle); ?></h1>
                                  <p>Silahkan Jelajahi <?php echo e($subTitle); ?>.</p>
                                <?php endif; ?>
                              </div>
                              <div>
                                  <a href="" class="btn btn-link btn-soft-light">
                                      <?php if($title === null): ?>
                                        <?php echo e($subTitle); ?>

                                        <?php else: ?>
                                        <?php echo e($title); ?> / <?php echo e($subTitle); ?>

                                      <?php endif; ?>
                                  </a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="iq-header-img">
                  <img src="<?php echo e(asset('template/html/assets/images/dashboard/top-header.png')); ?>" alt="header" class="theme-color-default-img img-fluid w-100 h-100 animated-scaleX">
                  <img src="<?php echo e(asset('template/html/assets/images/dashboard/top-header1.png')); ?>" alt="header" class="theme-color-purple-img img-fluid w-100 h-100 animated-scaleX">
                  <img src="<?php echo e(asset('template/html/assets/images/dashboard/top-header2.png')); ?>" alt="header" class="theme-color-blue-img img-fluid w-100 h-100 animated-scaleX">
                  <img src="<?php echo e(asset('template/html/assets/images/dashboard/top-header3.png')); ?>" alt="header" class="theme-color-green-img img-fluid w-100 h-100 animated-scaleX">
                  <img src="<?php echo e(asset('template/html/assets/images/dashboard/top-header4.png')); ?>" alt="header" class="theme-color-yellow-img img-fluid w-100 h-100 animated-scaleX">
                  <img src="<?php echo e(asset('template/html/assets/images/dashboard/top-header5.png')); ?>" alt="header" class="theme-color-pink-img img-fluid w-100 h-100 animated-scaleX">
              </div>
          </div>          <!-- Nav Header Component End -->
        <!--Nav End-->
      </div>
      <div class="conatiner-fluid content-inner mt-n5 py-0">

        
        <?php echo $__env->yieldContent('content'); ?>

      </div>
      
      <!-- Footer Section Start -->
      <footer class="footer">
          <div class="footer-body">
              <ul class="left-panel list-inline mb-0 p-0">
                  <li class="list-inline-item"><a href="#">Politeknik Negeri Subang</a></li>
              </ul>
              <div class="right-panel">
                  ©<script>document.write(new Date().getFullYear())</script> Designed SI UKT
              </div>
          </div>
      </footer>

      <div class="modal fade" id="logout" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Apakah Anda yakin akan logout ?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <a href="/logout" type="button" class="btn btn-danger">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Library Bundle Script -->
    <script src="<?php echo e(asset('template/html/assets/js/core/libs.min.js')); ?>"></script>
    
    <!-- External Library Bundle Script -->
    <script src="<?php echo e(asset('template/html/assets/js/core/external.min.js')); ?>"></script>
    
    <!-- Widgetchart Script -->
    <script src="<?php echo e(asset('template/html/assets/js/charts/widgetcharts.js')); ?>"></script>
    
    <!-- mapchart Script -->
    <script src="<?php echo e(asset('template/html/assets/js/charts/vectore-chart.js')); ?>"></script>
    <script src="<?php echo e(asset('template/html/assets/js/charts/dashboard.js')); ?>" ></script>
    
    <!-- fslightbox Script -->
    <script src="<?php echo e(asset('template/html/assets/js/plugins/fslightbox.js')); ?>"></script>
    
    <!-- Settings Script -->
    <script src="<?php echo e(asset('template/html/assets/js/plugins/setting.js')); ?>"></script>
    
    <!-- Slider-tab Script -->
    <script src="<?php echo e(asset('template/html/assets/js/plugins/slider-tabs.js')); ?>"></script>
    
    <!-- Form Wizard Script -->
    <script src="<?php echo e(asset('template/html/assets/js/plugins/form-wizard.js')); ?>"></script>
    
    <!-- AOS Animation Plugin-->
    <script src="<?php echo e(asset('template/html/assets/vendor/aos/dist/aos.js')); ?>"></script>
    
    <!-- App Script -->
    <script src="<?php echo e(asset('template/html/assets/js/hope-ui.js')); ?>" defer></script>

    <script>
        // umum
        function readImage(input) {
          if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
              $('#load_image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
          }
        }
        $('#preview_image').change(function() {
          readImage(this);
        })
      </script>
  
     <script>
        window.setTimeout(function() {
        $(".alert").fadeTo(1500, 0).slideUp(1500, function() {
           $(this).remove();
        });
        }, 6000);
     </script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\si-ukt\resources\views/layout/main.blade.php ENDPATH**/ ?>