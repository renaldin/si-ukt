

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title"><?php echo e($subTitle); ?></h4>
                </div>
            </div>
            <div class="card-body">
                <div class="new-user-info">
                    <form action="<?php if($form === 'Tambah'): ?> /tambah-kelompok-ukt <?php elseif($form === 'Edit'): ?> /edit-kelompok-ukt/<?php echo e($detail->id_kelompok_ukt); ?> <?php endif; ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="form-label" for="program_studi">Program Studi</label>
                            <select name="program_studi" id="program_studi" class="selectpicker form-control <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-style="py-0" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>    
                                <?php elseif($form === 'Edit' || $form === 'Detail'): ?>
                                    <option value="<?php echo e($detail->program_studi); ?>"><?php echo e($detail->program_studi); ?></option>
                                <?php endif; ?>
                                <option value="D3 Keperawatan">D3 Keperawatan</option>
                                <option value="D3 Sistem Informasi">D3 Sistem Informasi</option>
                                <option value="D3 Agroindustri">D3 Agroindustri</option>
                                <option value="D3 Pemeliharaan Mesin">D3 Pemeliharaan Mesin</option>
                                <option value="D4 Teknologi Produksi Tanaman Pangan">D4 Teknologi Produksi Tanaman Pangan</option>
                                <option value="D4 Teknologi Rekayasa Manufaktur">D4 Teknologi Rekayasa Manufaktur</option>
                                <option value="D4 Teknologi Rekayasa Perangkat Lunak">D4 Teknologi Rekayasa Perangkat Lunak</option>
                            </select>
                            <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="kelompok_ukt">Kelompok UKT</label>
                            <select name="kelompok_ukt" id="kelompok_ukt" class="selectpicker form-control <?php $__errorArgs = ['kelompok_ukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-style="py-0" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>    
                                <?php elseif($form === 'Edit' || $form === 'Detail'): ?>
                                    <option value="<?php echo e($detail->kelompok_ukt); ?>"><?php echo e($detail->kelompok_ukt); ?></option>
                                <?php endif; ?>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                            </select>
                            <?php $__errorArgs = ['kelompok_ukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nominal">Nominal UKT</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nominal" name="nominal" value="<?php if($form === 'Tambah'): ?><?php echo e(old('nominal')); ?><?php elseif($form === 'Edit' || $form === 'Detail'): ?><?php echo e($detail->nominal); ?><?php endif; ?>"  <?php if($form === 'Detail'): ?> disabled <?php endif; ?> placeholder="Masukkan Nominal UKT">
                            <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                        <br>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                        <a href="/daftar-kelompok-ukt" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-ukt\resources\views/bagianKeuangan/kelompokUKT/form.blade.php ENDPATH**/ ?>